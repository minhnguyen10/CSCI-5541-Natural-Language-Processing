import os.path
import argparse
from nltk import data

RULE_DICT = {}

def read_grammar(grammar_file):
    cfgrammar = []
    with open(grammar_file) as file:
        lines = file.readlines()
        for line in lines:
            cfgrammar.append(line.replace("->", "").split())
    return cfgrammar

def cnf_convert(grammar):
    cnf_grammar = []
    used_symbol = []
    index = 0

    for rule in grammar:
        new_rules = []
        if len(rule) > 2:    
            # Case: A -> X a.
            terminals = []
            for i, r in enumerate(rule):
                if r[0] == "'":
                    terminals.append((r, i))       
            if len(terminals) > 0:
                for item in terminals:
                    if f"{rule[0]}{str(index)}" in used_symbol:
                        rule[item[1]] = f"{rule[0]}{str(index+1)}"
                    else:
                        rule[item[1]] = f"{rule[0]}{str(index)}"
                    new_rules.append([f"{rule[0]}{str(index)}", item[0]])
                    
                index += 1
            # Case A -> X B C [...]
            while len(rule) > 3:
                new_rules.append([f"{rule[0]}{str(index)}", rule[1], rule[2]])
                rule = [rule[0]] + [f"{rule[0]}{str(index)}"] + rule[3:]
                index += 1
        cnf_grammar.append(rule)
        if len(new_rules) > 0:
            cnf_grammar.extend(new_rules)
    return cnf_grammar


def cyk_parse(cnf_grammar):
    return 0

def main():
    # argparser = argparse.ArgumentParser()
    # argparser.add_argument("grammar")
    # # argparser.add_argument("sentence")
    # args = argparser.parse_args()                                   
    # grammar_file = args.grammar
    # sentence = args.sentence
    
    grammar_file = "grammar2.cfg"
    setence = "i called mom at home"
    cnf_grammar = cnf_convert(read_grammar(grammar_file))
    # tree = cyk_parse(cnf_grammar)
    print(cnf_grammar)


# gm = data.load(grammar_file)
if __name__ == '__main__':
    main()